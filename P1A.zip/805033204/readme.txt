create.sql : Contains MySQL table creation.
load.sql   : Contains MySQL commands to load data from ~/data/ directory
queries.sql: Contains 4 SQL selections
query.php  : Contains php to have user interface on table operations
violate.sql: Contains constraints including primary key, check and referential intergrity.
